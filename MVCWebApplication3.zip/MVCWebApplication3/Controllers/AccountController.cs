﻿using Microsoft.AspNetCore.Mvc;
using MVCWebApplication3.Models; // Assuming your models are here

namespace MVCWebApplication3.Controllers
{
    public class AccountController : Controller
    {
        // GET: /Account/Register
        public ActionResult Register()
        {
            return View();
        }

        // POST: /Account/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(Register model)
        {
            if (ModelState.IsValid)
            {
                // Your registration logic here (e.g., save to database)
                // For simplicity, let's assume a successful registration
                return RedirectToAction("Login", "Account");
            }
            return View(model);
        }

        // GET: /Account/Login
        public ActionResult Login()
        {
            return View();
        }

        // POST: /Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Login model)
        {
            if (ModelState.IsValid)
            {
                // Your login logic here (e.g., validate credentials)
                // For simplicity, let's assume a successful login
                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }

        // POST: /Account/Logout
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Logout()
        {
            // Your logout logic here (e.g., sign out the user)
            // For simplicity, let's assume a successful logout
            return RedirectToAction("Index", "Home");
        }
    }
}
